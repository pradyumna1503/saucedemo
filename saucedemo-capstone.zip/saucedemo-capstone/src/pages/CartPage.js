class CartPage {
  constructor(page) {
    this.page = page;
    this.cartItems = page.locator('.cart_item');
    this.itemPrices = page.locator('.inventory_item_price');
    this.checkoutBtn = page.locator('[data-test="checkout"]');
    this.removeButtons = page.locator('button', { hasText: 'Remove' });
  }

  async getItemCount() {
    return this.cartItems.count();
  }

  async removeItemByName(name) {
    const item = this.page.locator('.cart_item', { hasText: name });
    await item.locator('button', { hasText: 'Remove' }).click();
  }

  async getSubtotal() {
    const texts = await this.itemPrices.allTextContents();
    return texts.reduce((sum, t) => sum + parseFloat(t.replace('$', '')), 0);
  }

  async startCheckout() {
    await this.checkoutBtn.click();
  }
}

module.exports = { CartPage };
