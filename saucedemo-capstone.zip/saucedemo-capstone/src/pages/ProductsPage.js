class ProductsPage {
  constructor(page) {
    this.page = page;
    this.inventoryItems = page.locator('.inventory_item');
    this.cartBadge = page.locator('.shopping_cart_badge');
    this.cartIcon = page.locator('.shopping_cart_link');
    this.sortDropdown = page.locator('[data-test="product-sort-container"]');
    this.itemPrices = page.locator('.inventory_item_price');
    this.itemNames = page.locator('.inventory_item_name');
  }

  async getItemCount() {
    return this.inventoryItems.count();
  }

  async addToCartByName(name) {
    const item = this.page.locator('.inventory_item', { hasText: name });
    await item.locator('button', { hasText: 'Add to cart' }).click();
  }

  async removeFromCartByName(name) {
    const item = this.page.locator('.inventory_item', { hasText: name });
    await item.locator('button', { hasText: 'Remove' }).click();
  }

  async getCartBadgeCount() {
    if (await this.cartBadge.count() === 0) return 0;
    return Number(await this.cartBadge.textContent());
  }

  async openCart() {
    await this.cartIcon.click();
  }

  async sortBy(option) {
    await this.sortDropdown.selectOption(option);
  }

  async getAllPrices() {
    const texts = await this.itemPrices.allTextContents();
    return texts.map(t => parseFloat(t.replace('$', '')));
  }

  async getAllNames() {
    return this.itemNames.allTextContents();
  }

  async openProductByName(name) {
    await this.page.locator('.inventory_item_name', { hasText: name }).click();
  }
}

module.exports = { ProductsPage };
