class ProductDetailPage {
  constructor(page) {
    this.page = page;
    this.name = page.locator('.inventory_details_name');
    this.desc = page.locator('.inventory_details_desc');
    this.price = page.locator('.inventory_details_price');
    this.addToCartBtn = page.locator('button', { hasText: 'Add to cart' });
    this.backBtn = page.locator('#back-to-products');
  }

  async getName() {
    return this.name.textContent();
  }

  async getDescription() {
    return this.desc.textContent();
  }

  async getPrice() {
    return this.price.textContent();
  }

  async addToCart() {
    await this.addToCartBtn.click();
  }

  async goBack() {
    await this.backBtn.click();
  }
}

module.exports = { ProductDetailPage };
