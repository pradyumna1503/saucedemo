class CheckoutPage {
  constructor(page) {
    this.page = page;
    // Step One - info
    this.firstName = page.locator('[data-test="firstName"]');
    this.lastName = page.locator('[data-test="lastName"]');
    this.postalCode = page.locator('[data-test="postalCode"]');
    this.continueBtn = page.locator('[data-test="continue"]');
    this.errorMsg = page.locator('[data-test="error"]');

    // Step Two - overview
    this.finishBtn = page.locator('[data-test="finish"]');
    this.itemTotal = page.locator('.summary_subtotal_label');

    // Step Three - complete
    this.completeHeader = page.locator('.complete-header');
    this.completeText = page.locator('.complete-text');
  }

  async fillInfo(firstName, lastName, postalCode) {
    await this.firstName.fill(firstName);
    await this.lastName.fill(lastName);
    await this.postalCode.fill(postalCode);
  }

  async continueCheckout() {
    await this.continueBtn.click();
  }

  async getErrorText() {
    return this.errorMsg.textContent();
  }

  async finishOrder() {
    await this.finishBtn.click();
  }

  async getConfirmationHeader() {
    return this.completeHeader.textContent();
  }

  async getConfirmationText() {
    return this.completeText.textContent();
  }
}

module.exports = { CheckoutPage };
