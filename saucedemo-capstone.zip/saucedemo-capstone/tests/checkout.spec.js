const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../src/pages/LoginPage');
const { ProductsPage } = require('../src/pages/ProductsPage');
const { CartPage } = require('../src/pages/CartPage');
const { CheckoutPage } = require('../src/pages/CheckoutPage');

const VALID_USER = 'standard_user';
const PASSWORD = 'secret_sauce';

async function loginAndAddItem(page, productName = 'Sauce Labs Backpack') {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login(VALID_USER, PASSWORD);

  const productsPage = new ProductsPage(page);
  await productsPage.addToCartByName(productName);
  return productsPage;
}

test.describe('Checkout Tests', () => {

  test('checkout with empty cart shows no items but allows navigation', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(VALID_USER, PASSWORD);

    const productsPage = new ProductsPage(page);
    await productsPage.openCart();

    const cartPage = new CartPage(page);
    const itemCount = await cartPage.getItemCount();
    expect(itemCount).toBe(0);

    await cartPage.startCheckout();
    await expect(page).toHaveURL(/checkout-step-one.html/);
  });

  test('checkout with empty first name shows error', async ({ page }) => {
    const productsPage = await loginAndAddItem(page);
    await productsPage.openCart();

    const cartPage = new CartPage(page);
    await cartPage.startCheckout();

    const checkoutPage = new CheckoutPage(page);
    await checkoutPage.fillInfo('', 'Doe', '12345');
    await checkoutPage.continueCheckout();

    const error = await checkoutPage.getErrorText();
    expect(error).toContain('First Name is required');
  });

  test('checkout with empty postal code shows error', async ({ page }) => {
    const productsPage = await loginAndAddItem(page);
    await productsPage.openCart();

    const cartPage = new CartPage(page);
    await cartPage.startCheckout();

    const checkoutPage = new CheckoutPage(page);
    await checkoutPage.fillInfo('John', 'Doe', '');
    await checkoutPage.continueCheckout();

    const error = await checkoutPage.getErrorText();
    expect(error).toContain('Postal Code is required');
  });

  test('happy path - complete checkout flow successfully', async ({ page }) => {
    const productsPage = await loginAndAddItem(page);
    await productsPage.openCart();

    const cartPage = new CartPage(page);
    await cartPage.startCheckout();

    const checkoutPage = new CheckoutPage(page);
    await checkoutPage.fillInfo('John', 'Doe', '12345');
    await checkoutPage.continueCheckout();

    await expect(page).toHaveURL(/checkout-step-two.html/);
    await expect(checkoutPage.itemTotal).toBeVisible();

    await checkoutPage.finishOrder();
    await expect(page).toHaveURL(/checkout-complete.html/);

    const header = await checkoutPage.getConfirmationHeader();
    const text = await checkoutPage.getConfirmationText();

    expect(header).toContain('Thank you for your order');
    expect(text.length).toBeGreaterThan(0);
  });

  test('security - script tag in checkout name field is escaped', async ({ page }) => {
    const productsPage = await loginAndAddItem(page);
    await productsPage.openCart();

    const cartPage = new CartPage(page);
    await cartPage.startCheckout();

    const checkoutPage = new CheckoutPage(page);

    let dialogTriggered = false;
    page.on('dialog', () => { dialogTriggered = true; });

    await checkoutPage.fillInfo('<script>alert(1)</script>', 'Doe', '12345');
    await checkoutPage.continueCheckout();

    expect(dialogTriggered).toBe(false);
    await expect(page).toHaveURL(/checkout-step-two.html/);
  });
});
