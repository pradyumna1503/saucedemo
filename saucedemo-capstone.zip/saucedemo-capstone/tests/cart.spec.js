const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../src/pages/LoginPage');
const { ProductsPage } = require('../src/pages/ProductsPage');
const { CartPage } = require('../src/pages/CartPage');

const VALID_USER = 'standard_user';
const PASSWORD = 'secret_sauce';

async function loginAsStandardUser(page) {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login(VALID_USER, PASSWORD);
}

test.describe('Cart Tests', () => {

  test('add multiple distinct products updates cart badge', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    await productsPage.addToCartByName('Sauce Labs Backpack');
    await productsPage.addToCartByName('Sauce Labs Bike Light');
    await productsPage.addToCartByName('Sauce Labs Bolt T-Shirt');

    const badgeCount = await productsPage.getCartBadgeCount();
    expect(badgeCount).toBe(3);
  });

  test('remove product from products page updates cart badge', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    await productsPage.addToCartByName('Sauce Labs Backpack');
    await productsPage.addToCartByName('Sauce Labs Bike Light');
    expect(await productsPage.getCartBadgeCount()).toBe(2);

    await productsPage.removeFromCartByName('Sauce Labs Backpack');
    expect(await productsPage.getCartBadgeCount()).toBe(1);
  });

  test('cart page shows correct item count and subtotal', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const cartPage = new CartPage(page);

    await productsPage.addToCartByName('Sauce Labs Backpack');
    await productsPage.addToCartByName('Sauce Labs Bike Light');
    await productsPage.openCart();

    const itemCount = await cartPage.getItemCount();
    expect(itemCount).toBe(2);

    const subtotal = await cartPage.getSubtotal();
    expect(subtotal).toBeGreaterThan(0);
  });

  test('remove item from cart page updates item count', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const cartPage = new CartPage(page);

    await productsPage.addToCartByName('Sauce Labs Backpack');
    await productsPage.addToCartByName('Sauce Labs Bike Light');
    await productsPage.openCart();

    await cartPage.removeItemByName('Sauce Labs Backpack');
    const itemCount = await cartPage.getItemCount();
    expect(itemCount).toBe(1);
  });

  test('simulate quantity update by adding then removing same item', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    await productsPage.addToCartByName('Sauce Labs Backpack');
    expect(await productsPage.getCartBadgeCount()).toBe(1);

    await productsPage.removeFromCartByName('Sauce Labs Backpack');
    expect(await productsPage.getCartBadgeCount()).toBe(0);

    await productsPage.addToCartByName('Sauce Labs Backpack');
    expect(await productsPage.getCartBadgeCount()).toBe(1);
  });
});
