const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../src/pages/LoginPage');

const VALID_USER = 'standard_user';
const PASSWORD = 'secret_sauce';

test.describe('Login Tests', () => {

  test('valid login navigates to inventory page', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(VALID_USER, PASSWORD);
    await expect(page).toHaveURL(/inventory.html/);
    await expect(page.locator('.inventory_list')).toBeVisible();
  });

  test('invalid credentials show error', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('invalid_user', 'wrong_pass');
    const error = await loginPage.getErrorText();
    expect(error).toContain('Username and password do not match');
  });

  test('locked out user shows locked error', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('locked_out_user', PASSWORD);
    const error = await loginPage.getErrorText();
    expect(error).toContain('locked out');
  });

  test('empty username and password shows required error', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('', '');
    const error = await loginPage.getErrorText();
    expect(error).toContain('Username is required');
  });

  test('empty password shows password required error', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(VALID_USER, '');
    const error = await loginPage.getErrorText();
    expect(error).toContain('Password is required');
  });

  test('security - script tag in username field is escaped, not executed', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();

    let dialogTriggered = false;
    page.on('dialog', () => { dialogTriggered = true; });

    await loginPage.login('<script>alert("xss")</script>', PASSWORD);

    expect(dialogTriggered).toBe(false);
    const error = await loginPage.getErrorText();
    expect(error).toContain('Username and password do not match');
  });
});
