const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../src/pages/LoginPage');
const { ProductsPage } = require('../src/pages/ProductsPage');
const { ProductDetailPage } = require('../src/pages/ProductDetailPage');

const VALID_USER = 'standard_user';
const PASSWORD = 'secret_sauce';

async function loginAsStandardUser(page) {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login(VALID_USER, PASSWORD);
}

test.describe('Product Listing Tests', () => {

  test('product list has items greater than 0', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const count = await productsPage.getItemCount();
    expect(count).toBeGreaterThan(0);
  });

  test('each product tile has image, name, price, and add button', async ({ page }) => {
    await loginAsStandardUser(page);
    const items = page.locator('.inventory_item');
    const count = await items.count();

    for (let i = 0; i < count; i++) {
      const item = items.nth(i);
      await expect(item.locator('img')).toBeVisible();
      await expect(item.locator('.inventory_item_name')).toBeVisible();
      await expect(item.locator('.inventory_item_price')).toBeVisible();
      await expect(item.locator('button', { hasText: 'Add to cart' })).toBeVisible();
    }
  });

  test('sort products by price low to high', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    await productsPage.sortBy('lohi');
    const prices = await productsPage.getAllPrices();
    const sorted = [...prices].sort((a, b) => a - b);
    expect(prices).toEqual(sorted);
  });

  test('sort products by name Z to A', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    await productsPage.sortBy('za');
    const names = await productsPage.getAllNames();
    const sorted = [...names].sort().reverse();
    expect(names).toEqual(sorted);
  });
});

test.describe('Product Detail Tests', () => {

  test('open product detail and validate fields, then go back', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const detailPage = new ProductDetailPage(page);

    await productsPage.openProductByName('Sauce Labs Backpack');
    await expect(page).toHaveURL(/inventory-item.html/);

    const name = await detailPage.getName();
    const desc = await detailPage.getDescription();
    const price = await detailPage.getPrice();

    expect(name).toBe('Sauce Labs Backpack');
    expect(desc.length).toBeGreaterThan(0);
    expect(price).toMatch(/^\$\d+\.\d{2}$/);

    await detailPage.addToCart();
    await expect(productsPage.cartBadge).toHaveText('1');

    await detailPage.goBack();
    await expect(page).toHaveURL(/inventory.html/);
  });
});
