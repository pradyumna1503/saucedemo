const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../src/pages/LoginPage');
const { ProductsPage } = require('../src/pages/ProductsPage');

const PASSWORD = 'secret_sauce';

test.describe('Edge Case Tests', () => {

  test('performance glitch user - inventory page eventually loads', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('performance_glitch_user', PASSWORD);

    await expect(page.locator('.inventory_list')).toBeVisible({ timeout: 15000 });
  });

  test('network failure - abort image requests, page still functions', async ({ page }) => {
    await page.route('**/*.{png,jpg,jpeg,svg}', route => route.abort());

    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', PASSWORD);

    const productsPage = new ProductsPage(page);
    const count = await productsPage.getItemCount();
    expect(count).toBeGreaterThan(0);
  });

  test('mock product inventory API response using route.fulfill', async ({ page }) => {
    await page.route('**/inventory.html', async (route) => {
      const response = await route.fetch();
      await route.fulfill({ response });
    });

    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', PASSWORD);

    await expect(page).toHaveURL(/inventory.html/);
  });

  test('mobile viewport - inventory page renders correctly', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 });

    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', PASSWORD);

    const productsPage = new ProductsPage(page);
    await expect(page.locator('.inventory_list')).toBeVisible();
    const count = await productsPage.getItemCount();
    expect(count).toBeGreaterThan(0);
  });

  test('accessibility - product images have alt text', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', PASSWORD);

    const images = page.locator('.inventory_item img');
    const count = await images.count();

    for (let i = 0; i < count; i++) {
      const alt = await images.nth(i).getAttribute('alt');
      expect(alt).not.toBeNull();
    }
  });

  test('accessibility - login inputs have placeholder/labels', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();

    const usernamePlaceholder = await loginPage.username.getAttribute('placeholder');
    const passwordPlaceholder = await loginPage.password.getAttribute('placeholder');

    expect(usernamePlaceholder).not.toBeNull();
    expect(passwordPlaceholder).not.toBeNull();
  });

  // Known flaky test - retries enabled only here
  test('flaky - cart badge appears quickly after add', async ({ page }) => {
    test.info().annotations.push({ type: 'flaky', description: 'Timing-sensitive badge update' });

    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', PASSWORD);

    const productsPage = new ProductsPage(page);
    await productsPage.addToCartByName('Sauce Labs Backpack');

    await expect(productsPage.cartBadge).toHaveText('1', { timeout: 3000 });
  });
});

// Apply retries only to the flaky test group below
test.describe('Flaky Tests - Retry Group', () => {
  test.describe.configure({ retries: 2 });

  test('flaky - sort dropdown reflects selection reliably', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', PASSWORD);

    const productsPage = new ProductsPage(page);
    await productsPage.sortBy('hilo');

    const prices = await productsPage.getAllPrices();
    const sorted = [...prices].sort((a, b) => b - a);
    expect(prices).toEqual(sorted);
  });
});
