# SauceDemo Playwright Capstone

End-to-end automation framework for https://www.saucedemo.com using Playwright (JavaScript) and the Page Object Model.

## Project Structure

```
src/pages/      -> Page Object classes (LoginPage, ProductsPage, etc.)
tests/          -> Test specs grouped by feature
playwright.config.js -> Playwright configuration
.github/workflows/   -> CI pipeline
```

## Setup

1. Open this folder in VS Code.
2. Install dependencies:
   ```
   npm install
   ```
3. Install Playwright browsers:
   ```
   npx playwright install
   ```

## Running Tests

Run all tests (chromium + mobile):
```
npm test
```

Run only chromium:
```
npm run test:chromium
```

Run only mobile viewport tests:
```
npm run test:mobile
```

Run in headed mode (visible browser):
```
npm run test:headed
```

View the HTML report after a run:
```
npm run test:report
```

## Test Coverage

- **Login**: valid login, invalid credentials, locked out user, empty field validation, security/XSS input handling
- **Products**: item count, tile element validation (image/name/price/button), sorting (price & name)
- **Product Detail**: open detail page, validate name/description/price, add to cart, back navigation
- **Cart**: add multiple items, remove items, badge count updates, subtotal calculation
- **Checkout**: empty cart flow, validation errors, happy path with order confirmation, XSS input handling
- **Edge Cases**: performance_glitch_user (slow load), aborted image requests, mocked route, mobile viewport, accessibility (alt text, input placeholders)

## Flaky Test Handling

- Tests known to be timing-sensitive are annotated with `flaky` and grouped under `test.describe.configure({ retries: 2 })`.
- All other tests run with `retries: 0`.

## Reporting & Debugging

- Traces, screenshots, videos retained on failure.
- HTML report generated in `playwright-report/`.
- CI uploads `playwright-report/` and `test-results/` as artifacts.

## CI/CD

GitHub Actions workflow (`.github/workflows/playwright.yml`) runs on push/PR to `main`, executes the suite, and uploads reports/traces/videos.

## Test Users (SauceDemo)

| Username                  | Password      | Behavior              |
|---------------------------|----------------|-----------------------|
| standard_user              | secret_sauce   | Normal flow           |
| locked_out_user            | secret_sauce   | Login blocked         |
| performance_glitch_user    | secret_sauce   | Slow page loads       |

## Parallelism

Each test logs in independently with no shared state. `fullyParallel: true` is enabled.
